insmod lin_net_device.ko 
insmod lin_net1.ko 
insmod lin_net2.ko 

ifconfig lin1 192.168.0.1
ifconfig lin1 up
ifconfig lin2 192.168.1.1
ifconfig lin2 up
