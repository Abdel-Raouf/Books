rmmod lin_net1.ko 
rmmod lin_net2.ko 
rmmod lin_net_device.ko 

ifconfig lin1 down
ifconfig lin2 down
