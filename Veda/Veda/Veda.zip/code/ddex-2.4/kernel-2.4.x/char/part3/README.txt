README.txt
==========

Compile the driver char_driver_blocking.c using the normal compile 
procedures. Insert it into the kernel blob using insmod.

There are three programs in this directory
reader1.c, reader2.c and writer.c

compile each program and have different executables.

Run reader1 in one console
Run reader2 in another console
Run writer in another console

and in that order. 

Notice the program output and arrive at the conclusions.
