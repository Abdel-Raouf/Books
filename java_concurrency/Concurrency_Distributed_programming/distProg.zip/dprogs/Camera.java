public interface Camera extends MsgHandler {
    void globalState();
}
