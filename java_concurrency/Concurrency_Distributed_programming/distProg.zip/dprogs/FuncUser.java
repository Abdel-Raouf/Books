public interface FuncUser {
  public int func(int x, int y);
}
