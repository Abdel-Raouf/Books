public interface CamUser extends MsgHandler {
    void localState();
}
