class SafeBoolean {
    boolean value; 
    public boolean getValue() {
        return value;
    }
    public void setValue(boolean b) {
            value = b;
    }
}

