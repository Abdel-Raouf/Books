interface Resource {
    public void acquire(int i);
    public void release(int i);
}
