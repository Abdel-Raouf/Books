public class ObjPointer {
    public Object obj;
    public int version;
}
