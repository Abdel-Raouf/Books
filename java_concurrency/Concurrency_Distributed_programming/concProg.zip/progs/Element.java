public class Element {
    public String data;
    public Pointer next;
}
